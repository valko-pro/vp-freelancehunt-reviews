=== VP+ Freelancehunt Review ===
Contributors: olegvalko
Tags: freelancehunt, freelance, reviews
Donate link: https://goo.gl/Q6NXgN
Requires at least: 5.0.3
Tested up to: 5.0.3
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin display your reviews from freelancehunt.com

== Description ==
This plugin display your reviews from freelancehunt.com 

**This plugin work with plugin VP+ Freelancehunt API**

**VP+ Freelancehunt API is aviable in:**

- Ukrainian (In the next version)
- English
- Russian (In the next version)

**Author this plugin:**
[Oleg Valko](http://valko.pro)
[Twitter](https://twitter.com/valko_pro)
[Facebook](https://www.facebook.com/valko.pro)

== Installation ==

1. Install and setting plugin VP+ Freelancehunt API
2. Install and activate this plugin
3. Use shortcode [freelancehunt_reviews] to display your reviews

== Changelog == 

= 1.0 =
* Release

== Screenshots ==

1. Reviews carousel
